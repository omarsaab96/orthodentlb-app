import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
    server: {
        cors: {
            origin: '*', // Allows all origins (use specific domains in production)
            methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        },
    },
    plugins: [
        laravel({
            input: 'resources/js/app.js',
            refresh: true,
        }),
        vue({
            template: {
                transformAssetUrls: {
                    base: null,
                    includeAbsolute: false,
                },
            },
        }),
    ],
    optimizeDeps: {
        include: ["swiper/vue"],
    },
    base: './',
});
