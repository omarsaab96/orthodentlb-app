<?php echo e($slot); ?>

<?php /**PATH C:\Users\User\Desktop\orthodentlb-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>